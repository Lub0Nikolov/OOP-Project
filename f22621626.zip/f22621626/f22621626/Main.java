package f22621626;

import f22621626.App.AppMenu;
import f22621626.App.AppLogger;

import java.io.File;
import java.util.Scanner;

// IMB
// * Structured and readable: The code itself is the documentation
// * This is the starting point - keep it as minimal as possible.
// * Everything that needs to happen - is codded and happens somewhere else

public class Main {
    private static CalendarManager calendarManager = new CalendarManager();
    private static boolean isRunning = true;

    public static void main(String[] args) {
        AppLogger.logInfo("Application started");
        Scanner scanner = new Scanner(System.in);

        while (isRunning) {
            AppMenu.print();

            String prompt = getPrompt(calendarManager);
            System.out.print(prompt);
            
            String commandLine = scanner.nextLine();
            String[] commandParts = commandLine.split("\\s+", 2); // Split command and parameters
            String command = commandParts[0];
            String params = (commandParts.length > 1) ? commandParts[1] : null;

            isRunning = CommandProcessor.process(calendarManager, command, params);
        }

        AppLogger.logInfo("Application ended");
    }

    private static String getPrompt(CalendarManager calendarManager) {
        File currentFile = calendarManager.getCurrentFile();
        if (currentFile != null) {
            return "[" + currentFile.getName() + "] > ";
        } else {
            return "[No Calendar] > ";
        }
    }
}
## Change log

> [!IMPORTANT]
> - I am not a Java programmer!
> - Spent all the years as C# developer. Have touched a bit Java in my student years (maybe 10 years ago)
> - PLEASE DO CHECK the code for naming convensions and if something does not look right -> rename accordingly.

> [!NOTE]
> - Everywhere I have found to be relevant I have added comments with explanations (mainly in the beginning of the file)
> - You can find these if you do search in all files for 'IMB'
> - Code is improved to some extend - not too much tho. Wanted to balance the improvements and the complexity.

### Project structure

f22621626
- App
  - All the App related stuff - Logger, app menu and menu commands
- Commands
  - "Handlers" for all commands - the code/logic for each command
- Models
  - The classes used for the ...
- CommandProcessor.java
  - The "orchestrator" of the commands - the part that handles which command will be executed based on the user input
- Main.java
  - The starting point



Tested and working
- open
- close
- save
- saveas
- help
- exit
- book
- unbook
- agenda
- change
- find
- showbusy
- setholiday
- findslot

Not implemented
- findslotwith
- merge

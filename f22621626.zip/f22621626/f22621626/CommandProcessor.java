package f22621626;

import f22621626.App.AppLogger;
import f22621626.App.AppMenuCommand;
import f22621626.Commands.*;

import java.util.Scanner;

public class CommandProcessor {
    private static boolean result = true;

    public static boolean process(CalendarManager calendarManager, String commandAction, String params) {
        String message = "";

        AppMenuCommand command = AppMenuCommand.getByAction(commandAction);

        switch (command) {
            case BOOK_APPOINTMENT:
                new BookCommand(calendarManager, command).execute(params);
                LogCommandExecution(command, params);
                break;
            case UNBOOK_APPOINTMENT:
                new UnbookCommand(calendarManager, command).execute(params);
                LogCommandExecution(command, params);
                break;
            case SHOW_AGENDA:
                new AgendaCommand(calendarManager).execute(params);
                LogCommandExecution(command, params);
                break;
            case CHANGE_APPOINTMENT:
                new ChangeCommand(calendarManager, command).execute(params);
                break;
            case FIND_APPOINTMENT:
                new FindCommand(calendarManager).execute(params);
                break;
            case SET_HOLIDAY:
                new HolidayCommand(calendarManager).execute(params);
                LogCommandExecution(command, params);
                break;
            case SHOW_BUSY_DAYS:
                new ShowBusyDaysCommand(calendarManager, command).execute(params);
                LogCommandExecution(command, params);
                break;
            case FIND_SLOT:
                new FindSlotCommand(calendarManager, command).execute(params);
                break;
            case OPEN_FILE:
                new OpenCommand(calendarManager).execute(params);
                LogCommandExecution(command, params);
                break;
            case SAVE_FILE:
                new SaveCommand(calendarManager).execute(params);
                LogCommandExecution(command);
                break;
            case SAVE_AS_NEW_FILE:
                new SaveAsCommand(calendarManager).execute(params);
                LogCommandExecution(command, params);
                break;
            case CLOSE_CALENDAR:
                new CloseCommand(calendarManager).execute(params);
                LogCommandExecution(command);
                break;
            case SHOW_HELP:
                new HelpCommand(calendarManager).execute("");
                LogCommandExecution(command);
                break;
            case EXIT_PROGRAM:
                result = false;
                message = "Program exited.";
                System.out.println(message);
                AppLogger.logInfo(message);
                break;
            default:
                message = "Unknown option. Please select a valid option.";
                System.out.println(message);
                AppLogger.logWarning(message);
                break;
        }

        return result;
    }

    private static void LogCommandExecution(AppMenuCommand command) {
        AppLogger.logInfo("Command executed: " + command.getAction());
    }

    private static void LogCommandExecution(AppMenuCommand command, String params) {
        AppLogger.logInfo("Command executed: " + command.getAction() + " " + params);
    }
}
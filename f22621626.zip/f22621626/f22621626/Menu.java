package f22621626;

import f22621626.App.AppLogger;
import f22621626.Models.Appointment;
import f22621626.Models.Calendar;

import java.io.IOException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

public class Menu {
    private Calendar calendar;
    private String filePath;
    private Map<Integer, Runnable> commands;
    private String[] commandList;

    public Menu(Calendar calendar, String filePath) {
        this.calendar = calendar;
        this.filePath = filePath;
        initializeCommands();
    }

    private void initializeCommands() {
        commands = new HashMap<>();
        commandList = new String[]{
                "Book an appointment",
                "Unbook an appointment",
                "Show agenda",
                "Find an appointment",
                "Show busy days",
                "Open a file",
                "Save the file",
                "Save as a new file",
                "Close the calendar",
                "Show help",
                "Exit program",
                "Set a holiday"
        };

        commands.put(1, this::book);
        commands.put(2, this::unbook);
        commands.put(3, this::agenda);
        commands.put(4, this::findAppointment);
        commands.put(5, this::showBusyDays);
        commands.put(6, this::openFile);
        commands.put(7, this::saveFile);
        commands.put(8, this::saveFileAs);
        commands.put(9, this::closeCalendar);
        commands.put(10, this::showHelp);
        commands.put(11, this::exitProgram);
        commands.put(12, this::setHoliday);
    }

    public void executeMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice = -1;  // Initialize choice to an invalid number

        AppLogger.logInfo("Menu execution started.");

        do {
            displayMenu();
            System.out.print("Enter the number of your choice (or type 11 to exit): ");

            try {
                choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                // Log the entered choice
                AppLogger.logInfo("User entered choice #" + choice + "-" + commandList[choice - 1]); // IMB: Changed to also log the command name

                // Execute the command if it exists in the map
                Runnable action = commands.get(choice);
                if (action != null) {
                    action.run();
                } else if (choice != 11) {
                    System.out.println("Unknown choice. Please try again.");
                    AppLogger.logInfo("Unknown choice entered.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                AppLogger.logInfo("Invalid input: " + e.getMessage());
                scanner.nextLine();  // Clear the invalid input
            }
        } while (choice != 11);

        AppLogger.logInfo("Menu execution ended.");
    }

    private void displayMenu() {
        System.out.println("Available commands:");
        for (int i = 0; i < commandList.length; i++) {
            System.out.println((i + 1) + ". " + commandList[i]);
        }
    }

    private void book() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter appointment date (YYYY-MM-DD): ");
        String date = scanner.nextLine().trim();

        System.out.println("Enter start time (HH:MM): ");
        String startTime = scanner.nextLine().trim();

        System.out.println("Enter end time (HH:MM): ");
        String endTime = scanner.nextLine().trim();

        System.out.println("Enter appointment name: ");
        String name = scanner.nextLine().trim();

        System.out.println("Enter appointment note: ");
        String note = scanner.nextLine().trim();

        Appointment appointment = new Appointment(date, startTime, endTime, name, note);
        calendar.book(appointment);
    }

    private void unbook() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter appointment date (YYYY-MM-DD): ");
        String date = scanner.nextLine().trim();

        System.out.println("Enter start time (HH:MM): ");
        String startTime = scanner.nextLine().trim();

        System.out.println("Enter end time (HH:MM): ");
        String endTime = scanner.nextLine().trim();

        System.out.println("Enter appointment name: ");
        String name = scanner.nextLine().trim();

        System.out.println("Enter appointment note: ");
        String note = scanner.nextLine().trim();

        Appointment appointment = new Appointment(date, startTime, endTime, name, note);
        calendar.unbook(appointment);  // Unbook the appointment
    }

    private void agenda() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter date for agenda (YYYY-MM-DD): ");
        String date = scanner.nextLine().trim();

        calendar.agenda(date).forEach(System.out::println);
    }

    private void findAppointment() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter search string: ");
        String searchString = scanner.nextLine().trim();

        calendar.find(searchString).forEach(System.out::println);
    }

    private void showBusyDays() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter start date (YYYY-MM-DD): ");
        String from = scanner.nextLine().trim();

        System.out.println("Enter end date (YYYY-MM-DD): ");
        String to = scanner.nextLine().trim();

        calendar.getBusyDays(from, to).forEach(System.out::println);
    }

    private void openFile() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter file path to open: ");
        String newFilePath = scanner.nextLine().trim();

        try {
            calendar.open(newFilePath);
            filePath = newFilePath; // Update file path
        } catch (IOException e) {
            System.out.println("Failed to open file: " + e.getMessage());
            AppLogger.logInfo("Failed to open file: " + e.getMessage());
        }
    }

    private void saveFile() {
        try {
            calendar.save();
        } catch (IOException e) {
            System.out.println("Failed to save file: " + e.getMessage());
            AppLogger.logInfo("Failed to save file: " + e.getMessage());
        }
    }

    private void saveFileAs() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter new file path to save as: ");
        String newFilePath = scanner.nextLine().trim();

        try {
            calendar.saveAs(newFilePath);
            filePath = newFilePath; // Update file path after saving
        } catch (IOException e) {
            System.out.println("Failed to save file as new file: " + e.getMessage());
            AppLogger.logInfo("Failed to save file as new file: " + e.getMessage());
        }
    }

    private void closeCalendar() {
        calendar.close();
    }

    private void showHelp() {
        displayMenu();
        AppLogger.logInfo("Help displayed.");
    }

    private void exitProgram() {
        AppLogger.logInfo("Exiting program.");
        System.out.println("Exiting program.");
    }

    private void setHoliday() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter holiday date (YYYY-MM-DD): ");
        String date = scanner.nextLine().trim();

        calendar.markHoliday(date);
    }
}

package f22621626;

import f22621626.App.AppMenuCommand;
import f22621626.Models.Appointment;

import java.io.*;
import java.util.*;

// IMB
// Responsible for managing all operations related to the calendar (appointments, holidays, availability, etc.).
// Holds the state and data of the calendar, like appointments and holidays.
// Handle the actual business logic that involves manipulating the calendar data and understanding its internal structure (appointments, holidays, etc.).

// Advantages:
// * Centralized Logic: All business logic is in CalendarManager, making it easier to update and maintain.
// * Loose Coupling: Commands are loosely coupled to the calendar’s internal logic. They don’t need to know how the calendar works; they just pass along the user’s input.
// * Reusability: If another command (or class) needs to any of the same functinality - it can be reused without duplicating logic.
// * Testability: The business logic can be tested independently from the command interface, allowing for better unit tests.

public class CalendarManager {
    private File currentFile = null;
    private Map<String, List<Appointment>> calendar = new HashMap<>();
    private Set<String> holidays = new HashSet<>();
    private static final String CSV_HEADER = "date,startTime,endTime,name,note";

    public void loadCalendarFromFile(File file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            calendar.clear(); // Clear the calendar before loading new data
            while ((line = br.readLine()) != null) {
                if (line.equals(CSV_HEADER)) continue; // Skip header

                String[] fields = line.split(",");
                if (fields.length == 5) {
                    String date = fields[0];
                    String startTime = fields[1];
                    String endTime = fields[2];
                    String name = fields[3];
                    String note = fields[4];
                    Appointment appointment = new Appointment(date, startTime, endTime, name, note);
                    calendar.computeIfAbsent(date, k -> new ArrayList<>()).add(appointment);
                }
            }
            currentFile = file;
            System.out.println("Successfully loaded calendar from CSV.");
        } catch (IOException e) {
            System.out.println("Error reading the CSV file: " + e.getMessage());
        }
    }

    public void saveCalendarToFile(File file) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
            bw.write(CSV_HEADER);
            bw.newLine();
            for (String date : calendar.keySet()) {
                for (Appointment appointment : calendar.get(date)) {
                    bw.write(date + "," + appointment.getStartTime() + "," + appointment.getEndTime() + ","
                        + appointment.getName() + "," + appointment.getNote());
                    bw.newLine();
                }
            }
            currentFile = file;
            System.out.println("Successfully saved calendar to CSV.");
        } catch (IOException e) {
            System.out.println("Error saving the CSV file: " + e.getMessage());
        }
    }

    public void save() {
        if (currentFile != null) {
            saveCalendarToFile(currentFile);
        } else {
            System.out.println("No file opened.");
        }
    }

    public void saveAs(String newFilename) {
        saveCalendarToFile(new File(newFilename));
    }

    public void clearCalendar() {
        calendar.clear();
        holidays.clear();
    }

    public void close() {
        currentFile = null;
        calendar.clear();
        holidays.clear();
        System.out.println("Successfully closed the file.");
    }

    public void book(String date, String startTime, String endTime, String name, String note) {
        Appointment appointment = new Appointment(date, startTime, endTime, name, note);
        calendar.computeIfAbsent(date, k -> new ArrayList<>()).add(appointment);
        System.out.println("Successfully booked appointment on " + date);
    }

    public void unbook(String date, String startTime, String endTime) {
        List<Appointment> appointments = calendar.get(date);
        if (appointments == null || appointments.isEmpty()) {
            System.out.println("No appointments found on " + date);
            return;
        }

        boolean appointmentFound = appointments.removeIf(appointment ->
            appointment.getStartTime().equals(startTime) &&
                appointment.getEndTime().equals(endTime)
        );

        if (appointmentFound) {
            System.out.println("Successfully unbooked appointment on " + date + " from " + startTime + " to " + endTime);
        } else {
            System.out.println("No appointment found on " + date + " with start time " + startTime + " and end time " + endTime);
        }
    }

    public void showAgenda(String date) {
        List<Appointment> appointments = calendar.get(date);
        if (appointments != null) {
            // Sort appointments by start time (assumes startTime is in "HH:mm" format)
            appointments.sort(Comparator.comparing(Appointment::getStartTime));

            System.out.println("\nAgenda for " + date + ":");
            System.out.println("========================");
            for (Appointment appointment : appointments) {
                System.out.println(appointment);
                System.out.println("------------------------");
            }
        } else {
            System.out.println("No appointments found for " + date);
        }
    }

    public void changeAppointment(String date, String startTime, String option, String newValue) {
        List<Appointment> appointments = calendar.get(date);
        if (appointments == null) {
            System.out.println("No appointments found on " + date);
            return;
        }

        for (Appointment appointment : appointments) {
            if (appointment.getStartTime().equals(startTime)) {
                switch (option.toLowerCase()) {
                    case "date":
                        List<Appointment> newDateAppointments = calendar.computeIfAbsent(newValue, k -> new ArrayList<>());
                        newDateAppointments.add(appointment);
                        appointments.remove(appointment);
                        System.out.println("Appointment moved to date " + newValue);
                        return;
                    case "starttime":
                        appointment.setStartTime(newValue);
                        System.out.println("Appointment start time changed to " + newValue);
                        return;
                    case "endtime":
                        appointment.setEndTime(newValue);
                        System.out.println("Appointment end time changed to " + newValue);
                        return;
                    case "name":
                        appointment.setName(newValue);
                        System.out.println("Appointment name changed to " + newValue);
                        return;
                    case "note":
                        appointment.setNote(newValue);
                        System.out.println("Appointment note changed to " + newValue);
                        return;
                    default:
                        System.out.println("Invalid option. Available options are: date, starttime, endtime, name, note.");
                        return;
                }
            }
        }
        System.out.println("No appointment found at " + startTime + " on " + date);
    }

    public void findAppointment(String query) {
        System.out.println("Appointments matching \"" + query + "\":");

        for (String date : calendar.keySet()) {
            for (Appointment appointment : calendar.get(date)) {
                if (appointment.getName().contains(query) || appointment.getNote().contains(query)) {
                    System.out.println("\n" + date + ":");
                    System.out.println(appointment);
                    System.out.println("------------------------");
                }
            }
        }
    }

    public void markHoliday(String date) {
        Appointment appointment = new Appointment(date, "00:00", "23:59", "HOLIDAY", "In vacation :)");
        calendar.computeIfAbsent(date, k -> new ArrayList<>()).add(appointment);
        System.out.println("Marked " + date + " as a holiday.");
    }

    public void showBusyDays(String from, String to) {
        Map<String, Integer> busyDays = new TreeMap<>();

        for (String date : calendar.keySet()) {
            if (date.compareTo(from) >= 0 && date.compareTo(to) <= 0) {
                busyDays.put(date, calendar.get(date).size());
            }
        }

        busyDays.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .forEach(entry -> System.out.println(entry.getKey() + ": " + entry.getValue() + " appointments"));
    }

    public void findSlot(String fromDate, int hours) {
        System.out.println("Searching for available slot starting from " + fromDate + " for " + hours + " hours.");

        int minutes = hours * 60;

        int startBusinessHour = 8 * 60; // 8 AM in minutes
        int endBusinessHour = 18 * 60; // 6 PM in minutes

        List<String> availableSlots = new ArrayList<>();
        List<int[]> busySlots = new ArrayList<>();

        for (Appointment appointment : calendar.get(fromDate)) {
            int startTime = convertTimeToMinutes(appointment.getStartTime());
            int endTime = convertTimeToMinutes(appointment.getEndTime());
            busySlots.add(new int[]{startTime, endTime});
        }

        busySlots.sort(Comparator.comparingInt(a -> a[0]));

        int lastEndTime = startBusinessHour;
        for (int[] busySlot : busySlots) {
            int start = busySlot[0];
            int end = busySlot[1];

            // Check for free time between lastEndTime and the start of the busy slot
            if (lastEndTime + minutes <= start) {
                availableSlots.add(convertMinutesToTime(lastEndTime) + " - " + convertMinutesToTime(lastEndTime + minutes));
            }

            // Move the end time pointer
            lastEndTime = Math.max(lastEndTime, end);
        }

        if (lastEndTime + minutes <= endBusinessHour) {
            availableSlots.add(convertMinutesToTime(lastEndTime) + " - " + convertMinutesToTime(lastEndTime + minutes));
        }

        System.out.println("The following slots are available:");
        for (String slot : availableSlots) {
            System.out.println(slot);
        }

    }

    public void help() {
        System.out.println("\n\nThe following commands are supported:\n");

        for (AppMenuCommand command : AppMenuCommand.getValues()) {
            String commandParams = "";

            if (command.getParams() != null && !command.getParams().trim().isEmpty()) {
                commandParams = " " + command.getParams();
            }

            System.out.println(command.getAction() + commandParams);
            System.out.println("-- " + command.getDisplayName());

            if (command.getHelpText() != null && !command.getHelpText().trim().isEmpty()) {
                System.out.println("-- " + command.getHelpText());
            }

            System.out.println();
        }

        System.out.println("\n\n");
    }

    // Getters and setters
    public File getCurrentFile() {
        return currentFile;
    }

    public void setCurrentFile(File currentFile) {
        this.currentFile = currentFile;
    }


    // Helper method to convert time in "HH:mm" format to minutes since midnight
    private int convertTimeToMinutes(String time) {
        String[] parts = time.split(":");
        return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
    }

    // Helper method to convert minutes since midnight to "HH:mm" format
    private String convertMinutesToTime(int minutes) {
        int hours = minutes / 60;
        int mins = minutes % 60;
        return String.format("%02d:%02d", hours, mins);
    }
}

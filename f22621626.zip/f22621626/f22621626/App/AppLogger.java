package f22621626.App;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

// IMB
// * Singleton-like Logger: Only one logger instance will handle all the logging. This ensures a centralized logging mechanism.
// * Log Levels: Use different levels (INFO, WARNING, SEVERE) for normal operations, warnings, and errors.
// * File Handling: The log file name is changed to app.log


// Why FileHandler instead of BufferedWriter - very shortly explined

// FileHandler:
//Typically used when you need to log application events or messages to a file. It handles the creation of log files, formats the output, and ensures log messages are stored efficiently.
//It works alongside Logger, which is responsible for recording events, messages, or errors.
//Example use case: Logging application errors, warnings, and info-level messages to a file during runtime.

//BufferedWriter:
//Used for writing textual data (like strings, characters, or even entire files) to a file or another stream in an efficient manner.
//Since it buffers data, it minimizes disk I/O operations, making it more efficient for writing large files.
//Example use case: Writing the content of a large text file to disk.

public class AppLogger {
    private static final Logger logger = Logger.getLogger("AppLogger");
    private static FileHandler fileHandler;

    static {
        try {
            // Disable console logging
            logger.setUseParentHandlers(false);

            // Configure logger to write to a file
            fileHandler = new FileHandler("app.log", true);
            fileHandler.setLevel(Level.ALL);
            fileHandler.setFormatter(new SimpleFormatter());

            logger.addHandler(fileHandler);
            logger.setLevel(Level.ALL);
        } catch (IOException e) {
            System.err.println("Failed to initialize logger: " + e.getMessage());
        }
    }

    public static void logInfo(String message) {
        logger.info(message);
    }

    public static void logWarning(String message) {
        logger.warning(message);
    }

    public static void logError(String message) {
        logger.severe(message);
    }

    public static void logError(Exception exception) {
        logger.log(Level.SEVERE, "An exception was thrown", exception);
    }
}

package f22621626.App;

// IMB
// * Nothing specific here - just prints the menu with all available commands.
// * Extraced in it's own file to improve manitability and readability.

public class AppMenu {
    public static void print() {
        System.out.println("\nAvailable commands:");

        for (AppMenuCommand command : AppMenuCommand.getValues()) {
            System.out.printf("%-20s %s\n", command.getAction(), command.getDisplayName());
        }
    }
}
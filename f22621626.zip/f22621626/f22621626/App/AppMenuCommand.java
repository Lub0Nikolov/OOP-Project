package f22621626.App;

// IMB
// Enum, enum, enum
// All commands in one place. Have all data about the commands that is needed.
// Easy add/remove/change commands without touching other files nor worring about command numbers and indexes while printing the menu.
// -- An excpetion is the `switch` that handles/executes the selcted command - in the CommandProcessor.java
// Maintanable and readable

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Objects;

public enum AppMenuCommand {
    BOOK_APPOINTMENT(
        "Book an appointment",
        "book",
        "<date> <starttime> <endtime> <name> <note>",
        "Additional helper text here if needed. Can include an example of the command written out with all parameters polulated with real values"),
    UNBOOK_APPOINTMENT(
        "Unbook an appointment",
        "unbook",
        "<date> <starttime> <endtime>",
        ""),
    SHOW_AGENDA(
        "Show agenda",
        "agenda",
        "<date>",
        ""),
    CHANGE_APPOINTMENT(
        "Change appointment",
        "change",
        "<date> <starttime> <option> <newvalue>",
        ""),
    FIND_APPOINTMENT(
        "Find an appointment",
        "find",
        "<string>",
        ""),
    SHOW_BUSY_DAYS(
        "Show busy days",
        "showbusy",
        "<from> <to>",
        ""),
    SET_HOLIDAY(
        "Set a holiday",
        "setholiday",
        "<date>",
        ""),
    FIND_SLOT(
        "Find an appointment",
        "findslot",
        "<fromdate> <hours>",
        ""),
    OPEN_FILE(
        "Open a calendar",
        "open",
        "<file>",
        ""),
    SAVE_FILE(
        "Save a calendar",
        "save",
        "",
        ""),
    SAVE_AS_NEW_FILE(
        "Save as a new calendar",
        "saveas",
        "<file>",
        ""),
    CLOSE_CALENDAR(
        "Close the calendar",
        "close",
        "",
        ""),
    SHOW_HELP(
        "Show help",
        "help",
        "",
        ""),
    EXIT_PROGRAM(
        "Exit program",
        "exit",
        "",
        ""),
    UNKNOWN_COMMAND(
        "UNKNOWN_COMMAND",
        "UNKNOWN_COMMAND",
        "",
        "");

    private final String displayName;

    private final String action;

    private final String params;

    private final String helpText;

    AppMenuCommand(String displayName, String action, String params, String helpText) {
        this.displayName = displayName;
        this.action = action;
        this.params = params;
        this.helpText = helpText;
    }

    public static List<AppMenuCommand> getValues() {
        List<AppMenuCommand> commands = new ArrayList<>(Arrays.asList(AppMenuCommand.values()));
        commands.remove(AppMenuCommand.UNKNOWN_COMMAND);

        return commands;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public String getAction() {
        return this.action;
    }

    public String getParams() {
        return this.params;
    }

    public int getParamsCount() {
        return this.params.split(" ").length;
    }

    public String getHelpText() {
        return this.helpText;
    }

    public static AppMenuCommand getByAction(String action) {
        try {
            for (AppMenuCommand menu : AppMenuCommand.values()) {
                if (Objects.equals(menu.action, action)) {
                    return menu;
                }
            }
        } catch (Exception exception) {
            AppLogger.logError(exception);
        }

        return AppMenuCommand.UNKNOWN_COMMAND;
    }
}

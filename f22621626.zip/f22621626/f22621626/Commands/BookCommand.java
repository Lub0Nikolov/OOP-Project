package f22621626.Commands;

import f22621626.App.AppMenuCommand;
import f22621626.CalendarManager;

public class BookCommand implements Command {
    private CalendarManager calendarManager;
    private AppMenuCommand command;

    public BookCommand(CalendarManager calendarManager, AppMenuCommand command) {
        this.calendarManager = calendarManager;
        this.command = command;
    }

    @Override
    public void execute(String params) {
        String[] parts = params.split("\\s+", command.getParamsCount());
        if (parts.length < command.getParamsCount()) {
            System.out.println("Error: Invalid parameters. Use: " + command.getAction() + command.getParams());
            return;
        }
        calendarManager.book(parts[0], parts[1], parts[2], parts[3], parts[4]);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

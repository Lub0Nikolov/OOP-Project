package f22621626.Commands;

import f22621626.CalendarManager;

public class HolidayCommand implements Command {
    private CalendarManager calendarManager;

    public HolidayCommand(CalendarManager calendarManager) {
        this.calendarManager = calendarManager;
    }

    @Override
    public void execute(String params) {
        calendarManager.markHoliday(params);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}
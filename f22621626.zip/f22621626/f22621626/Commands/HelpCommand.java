package f22621626.Commands;

import f22621626.CalendarManager;

public class HelpCommand implements Command {
    private CalendarManager calendarManager;

    public HelpCommand(CalendarManager calendarManager) {
        this.calendarManager = calendarManager;
    }

    @Override
    public void execute(String arguments) {
        calendarManager.help();
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}
package f22621626.Commands;

// IMB
// Commands are responsible for translating user input into actions that manipulate the calendar or retrieve data from it.
// They should delegate logic to the CalendarManager rather than perform the business logic themselves.

public interface Command {
    void execute(String arguments) throws Exception;

    boolean requiresInput();

    String getName();

    String getDescription();
}

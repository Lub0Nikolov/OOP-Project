package f22621626.Commands;

import f22621626.App.AppMenuCommand;
import f22621626.CalendarManager;

public class ShowBusyDaysCommand implements Command {
    private CalendarManager calendarManager;
    private AppMenuCommand command;

    public ShowBusyDaysCommand(CalendarManager calendarManager, AppMenuCommand command) {
        this.calendarManager = calendarManager;
        this.command = command;
    }

    @Override
    public void execute(String params) {
        String[] parts = params.split("\\s+");
        if (parts.length < command.getParamsCount()) {
            System.out.println("Error: Invalid parameters. Use: " + command.getAction() + command.getParams());
            return;
        }
        String fromDate = parts[0];
        String toDate = parts[1];

        // Delegate to CalendarManager to show busy days
        calendarManager.showBusyDays(fromDate, toDate);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

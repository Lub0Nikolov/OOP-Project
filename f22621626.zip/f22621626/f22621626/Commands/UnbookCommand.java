package f22621626.Commands;

import f22621626.App.AppMenuCommand;
import f22621626.CalendarManager;

public class UnbookCommand implements Command {
    private CalendarManager calendarManager;
    private AppMenuCommand command;

    public UnbookCommand(CalendarManager calendarManager, AppMenuCommand command) {
        this.calendarManager = calendarManager;
        this.command = command;
    }

    @Override
    public void execute(String params) {
        String[] parts = params.split("\\s+");
        if (parts.length < command.getParamsCount()) {
            System.out.println("Error: Invalid parameters. Use: " + command.getAction() + command.getParams());
            return;
        }
        String date = parts[0];
        String startTime = parts[1];
        String endTime = parts[2];

        calendarManager.unbook(date, startTime, endTime);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

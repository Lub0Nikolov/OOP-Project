package f22621626.Commands;

import f22621626.Models.Calendar;

public class ExitCommand implements Command {
    private final Calendar calendar;

    public ExitCommand(Calendar calendar) {
        this.calendar=calendar;
    }

    @Override
    public void execute(String arguments) {
        System.out.println("Exiting the program...");
        System.exit(0);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

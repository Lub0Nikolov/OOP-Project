package f22621626.Commands;

import f22621626.App.AppLogger;
import f22621626.CalendarManager;

import java.io.File;
import java.io.IOException;

public class OpenCommand implements Command {
    private CalendarManager calendarManager;

    public OpenCommand(CalendarManager calendarManager) {
        this.calendarManager = calendarManager;
    }

    @Override
    public void execute(String params) {
        if (params == null || params.isEmpty()) {
            System.out.println("Error: Please specify a file.");
            return;
        }
        File file = new File(params);
        if (file.exists()) {
            calendarManager.loadCalendarFromFile(file);
            System.out.println("Successfully opened " + params);
        } else {
            calendarManager.clearCalendar();
            System.out.println("Created new file: " + params);
        }
        calendarManager.setCurrentFile(file);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

package f22621626.Commands;

import f22621626.CalendarManager;

public class SaveCommand implements Command {
    private CalendarManager calendarManager;

    public SaveCommand(CalendarManager calendarManager) {
        this.calendarManager = calendarManager;
    }

    @Override
    public void execute(String params) {
        calendarManager.save();
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

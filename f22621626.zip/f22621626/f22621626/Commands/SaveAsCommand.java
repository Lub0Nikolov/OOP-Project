package f22621626.Commands;

import f22621626.CalendarManager;

public class SaveAsCommand implements Command {
    private CalendarManager calendarManager;

    public SaveAsCommand(CalendarManager calendarManager) {
        this.calendarManager = calendarManager;
    }

    @Override
    public void execute(String params) {
        if (params == null || params.isEmpty()) {
            System.out.println("Error: Please specify a new file name.");
            return;
        }
        calendarManager.saveAs(params);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

package f22621626.Commands;

import f22621626.CalendarManager;

public class AgendaCommand implements Command {
    private CalendarManager calendarManager;

    public AgendaCommand(CalendarManager calendarManager) {
        this.calendarManager = calendarManager;
    }

    @Override
    public void execute(String params) {
        calendarManager.showAgenda(params);
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

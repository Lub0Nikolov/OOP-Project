package f22621626.Commands;

import f22621626.App.AppMenuCommand;
import f22621626.CalendarManager;

public class FindSlotCommand implements Command {
    private CalendarManager calendarManager;
    private AppMenuCommand command;

    public FindSlotCommand(CalendarManager calendarManager, AppMenuCommand command) {
        this.calendarManager = calendarManager;
        this.command = command;
    }

    @Override
    public void execute(String params) {
        String[] parts = params.split("\\s+");
        if (parts.length < command.getParamsCount()) {
            System.out.println("Error: Invalid parameters. Use: " + command.getAction() + command.getParams());
            return;
        }
        calendarManager.findSlot(parts[0], Integer.parseInt(parts[1]));
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

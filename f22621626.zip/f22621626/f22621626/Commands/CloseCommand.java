package f22621626.Commands;

import f22621626.CalendarManager;

public class CloseCommand implements Command {
    private CalendarManager calendarManager;

    public CloseCommand(CalendarManager calendarManager) {
        this.calendarManager = calendarManager;
    }

    @Override
    public void execute(String params) {
        calendarManager.close();
    }

    @Override
    public boolean requiresInput() {
        return false;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }
}

package f22621626.Models;

import f22621626.App.AppLogger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Calendar {

    private boolean isOpen;
    private String filePath;
    private List<Appointment> appointments;

    public Calendar() {
        this.isOpen = false;
        this.appointments = new ArrayList<>();
    }

    // Checks if a file is open
    public boolean isOpen() {
        return isOpen;
    }

    // Opens a file
    public void open(String filePath) throws IOException {
        if (isOpen) {
            throw new IllegalStateException("A file is already open. Close it first.");
        }
        this.filePath = filePath;
        this.isOpen = true;
        AppLogger.logInfo("File " + filePath + " opened.");
        System.out.println("File " + filePath + " opened.");
    }

    // Closes the file
    public void close() {
        if (!isOpen) {
            throw new IllegalStateException("No file is open.");
        }
        this.filePath = null;
        this.isOpen = false;
        AppLogger.logInfo("File closed.");
        System.out.println("File closed.");
    }

    // Saves appointments to the file
    public void save() throws IOException {
        if (!isOpen) {
            throw new IllegalStateException("No file is open to save.");
        }
        AppLogger.logInfo("Appointments saved to " + filePath);
        System.out.println("Appointments saved to " + filePath);
    }

    // Saves appointments as a new file
    public void saveAs(String newFilePath) throws IOException {
        this.filePath = newFilePath;
        save();
        AppLogger.logInfo("Appointments saved as " + newFilePath);
        System.out.println("Appointments saved as " + newFilePath);
    }

    // Books a new appointment, checking for conflicts
    public boolean book(Appointment appointment) {
        if (isConflicting(appointment)) {
            AppLogger.logInfo("Scheduling conflict detected. Appointment not booked.");
            System.out.println("Scheduling conflict detected. Appointment not booked.");
            return false;
        }
        appointments.add(appointment);
        AppLogger.logInfo("Appointment booked: " + appointment);
        System.out.println("Appointment booked: " + appointment);
        return true;
    }

    // Checks for conflicts between appointments
    private boolean isConflicting(Appointment newAppointment) {
        for (Appointment appointment : appointments) {
            if (appointment.isOverlapping(newAppointment)) {
                return true;
            }
        }
        return false;
    }

    // Unbooks an appointment
    public void unbook(Appointment appointment) {
        if (appointments.remove(appointment)) {
            AppLogger.logInfo("Appointment unbooked: " + appointment);
            System.out.println("Appointment unbooked: " + appointment);
        } else {
            AppLogger.logInfo("Appointment not found: " + appointment);
            System.out.println("Appointment not found: " + appointment);
        }
    }

    // Shows appointments for a given date
    public List<Appointment> agenda(String date) {
        return appointments.stream()
            .filter(appt -> appt.getDate().equals(date))
            .collect(Collectors.toList());
    }

    // Finds appointments by a search string
    public List<Appointment> find(String searchString) {
        return appointments.stream()
            .filter(appt -> appt.getDate().contains(searchString) ||
                appt.getStartTime().contains(searchString) ||
                appt.getEndTime().contains(searchString) ||
                appt.getName().contains(searchString) ||
                appt.getNote().contains(searchString))
            .collect(Collectors.toList());
    }

    // Marks a day as a holiday
    public void markHoliday(String date) {
        Appointment holiday = new Appointment(date, "00:00", "23:59", "Holiday", "Holiday");
        appointments.add(holiday);
        AppLogger.logInfo("Holiday marked: " + date);
        System.out.println("Holiday marked: " + date);
    }

    // Returns a list of busy days in a given period
    public List<String> getBusyDays(String from, String to) {
        return appointments.stream()
            .map(Appointment::getDate)
            .filter(date -> date.compareTo(from) >= 0 && date.compareTo(to) <= 0)
            .distinct()
            .collect(Collectors.toList());
    }

    // Returns all appointments
    public List<Appointment> getAppointments() {
        return new ArrayList<>(appointments);
    }

    // Adds an appointment manually
    public void addAppointment(Appointment appointment) {
        if (!isConflicting(appointment)) {
            appointments.add(appointment);
            AppLogger.logInfo("Manually added appointment: " + appointment);
            System.out.println("Manually added appointment: " + appointment);
        } else {
            AppLogger.logInfo("Conflict detected. Appointment not added: " + appointment);
            System.out.println("Conflict detected. Appointment not added: " + appointment);
        }
    }

}
